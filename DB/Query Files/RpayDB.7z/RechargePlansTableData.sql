
---PLANS

------------------------------JIO-----------------------------------------
--PopularPlans
--insert into Plans values('Jio 2 GB/DAY Packs','Unlimited 112GB & Disney+ Hotstar',598,56,'Popular Plans',1000);

--insert into Plans values
--('Jio 1.5 GB/DAY Packs','Unlimited 131GB & Disney+ Hotstar',777,84,'Popular Plans',1000);

--insert into Plans values
--('Jio Long Term','350 GB UNLIMITED',4999,360,'Popular Plans',1000);

--insert into Plans values
--('Jio 3 GB/DAY Packs','252 GB UNLIMITED',999,84,'Popular Plans',1000);


----Top-Up
--insert into Plans values
--('Jio 1000 Talktime','Rs 844.46  Talktime',1000,365,'Top-Up',1000),
--('Jio 500 Talktime','Rs 420.73  Talktime',500,365,'Top-Up',1000),
--('Jio 100 Talktime','Rs 81.75  Talktime',100,365,'Top-Up',1000),
--('Jio 50 Talktime','Rs 39.37   Talktime',50,365,'Top-Up',1000),
--('Jio 20 Talktime','Rs 14.95  Talktime',20,365,'Top-Up',1000),
--('Jio 10 Talktime','Rs 7.47   Talktime',10,365,'Top-Up',1000);

-----4G Datavoucher
--insert into Plans values
--('Jio Disney Hotstar packs','Unlimited 72 GB+ 6000 minutes Jio to Non-Jio',612,28,'4G Data Voucher',1000);

--insert into Plans values
--('Jio Work from Home packs 1','Unlimited 50 GB',251,30,'4G Data Voucher',1000),
--('Jio Work from Home packs 2','Unlimited 40 GB',201,30,'4G Data Voucher',1000),
--('Jio Work from Home packs 3','Unlimited 30 GB',151,30,'4G Data Voucher',1000);


--insert into Plans values
--('Jio Add on 1','Unlimited 6 GB + 500 Minutes Jio to Non-Jio',51,28,'4G Data Voucher',1000),
--('Jio Add on 2','Unlimited 12 GB + 1000 Minutes Jio to Non-Jio',101,28,'4G Data Voucher',1000);

-----International Roaming
--insert into Plans values
--('Jio InFlight Connectivity','500 MB data, 100 mins Outgoing Voice Calls and 100 SMS',999,1,'International Roaming',1000),

--('Jio Value WiFi Calling','Rs 1018.64  IR usage',1202,28,'International Roaming',1000),

--('Jio Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',5751,30,'International Roaming',1000);
---------------------------------------------------------------------------------------------------------------

--select * from Plans where operator_id = 1000;


--***************************************************************************************************************--

------------------AIRTEL---------------------------
---POPULAR PLANS

--insert into Plans values
--('Airtel 1 GB/DAY Packs','Rs.129 Truly Unlimited Calls',129,28,'Popular Plans',1001),

--('Airtel 1.5 GB/DAY Packs','Rs.289 Truly Unlimited Calls',289,28,'Popular Plans',1001),

--('Airtel 2 GB/DAY Packs','Rs.349 Truly Unlimited Calls',349,28,'Popular Plans',1001),

--('Airtel 3 GB/DAY Packs','Rs.448 Truly Unlimited Calls',448,28,'Popular Plans',1001);



----Top-Up

--insert into Plans values
--('Airtel 1000 Talktime','Rs 960  Talktime',1000,365,'Top-Up',1001),
--('Airtel 500 Talktime','Rs 480  Talktime',500,365,'Top-Up',1001),
--('Airtel 100 Talktime','Rs 82  Talktime',100,28,'Top-Up',1001),
--('Airtel 20 Talktime','Rs 15  Talktime',20,28,'Top-Up',1001),
--('Airtel 10 Talktime','Rs 7  Talktime',10,28,'Top-Up',1001);


-----4G Data Voucher

--insert into Plans values
--('Airtel Xstream 1','250GB & Airtel Xstream',1208,240,'4G Data Voucher',1001),
--('Airtel Xstream 2','120GB & Airtel Xstream',1004,120,'4G Data Voucher',1001);

--insert into Plans values
--('Airtel Work from Home packs 1','Unlimited 50 GB',251,30,'4G Data Voucher',1001),
--('Airtel Work from Home packs 2','Unlimited 40 GB',201,30,'4G Data Voucher',1001),
--('Airtel Work from Home packs 3','Unlimited 30 GB',151,30,'4G Data Voucher',1001),

--('Airtel Add on 1','Unlimited 900 MB ',11,28,'4G Data Voucher',1001),
--('Airtel Add on 2','Unlimited 3 GB ',21,28,'4G Data Voucher',1001),
--('Airtel Add on 3','Unlimited 7 GB ',51,28,'4G Data Voucher',1001);

--select * from Plans;

-----International Roaming
--insert into Plans values
--('Airtel InFlight Connectivity','600 MB data, 100 mins Outgoing Voice Calls and 100 SMS',999,1,'International Roaming',1001),

--('Airtel Value WiFi Calling','Rs 1118.64  IR usage',1202,28,'International Roaming',1001),

--('Airtel Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',5751,30,'International Roaming',1001);

--select * from Plans where operator_id = 1001;

-------------------------------------------------------------------------------------------------------------
--*********************************************************************************************************--

------------------VodafoneI---------------------------
---POPULAR PLANS

--insert into Plans values
--('VodafoneI 1 GB/DAY Packs','Rs.119 Truly Unlimited Calls',119,28,'Popular Plans',1002),

--('VodafoneI 1.5 GB/DAY Packs','Rs.279 Truly Unlimited Calls',279,28,'Popular Plans',1002),

--('VodafoneI 2 GB/DAY Packs','Rs.339 Truly Unlimited Calls',339,28,'Popular Plans',1002),

--('VodafoneI 3 GB/DAY Packs','Rs.438 Truly Unlimited Calls',438,28,'Popular Plans',1002);



----Top-Up

--insert into Plans values
--('VodafoneI 700 Talktime','Rs 700  Talktime',700,365,'Top-Up',1002),
--('VodafoneI 400 Talktime','Rs 400  Talktime',400,365,'Top-Up',1002),
--('VodafoneI 70 Talktime','Rs 70  Talktime',70,28,'Top-Up',1002),
--('VodafoneI 20 Talktime','Rs 14  Talktime',20,28,'Top-Up',1002),
--('VodafoneI 10 Talktime','Rs 7  Talktime',10,28,'Top-Up',1002);


-----4G Data Voucher

--insert into Plans values
--('VodafoneI Playback 1','250GB & Airtel Xstream',1008,240,'4G Data Voucher',1002),
--('VodafoneI Playback 2','120GB & Airtel Xstream',904,120,'4G Data Voucher',1002);

--insert into Plans values
--('VodafoneI Work from Home packs 1','Unlimited 70 GB',251,30,'4G Data Voucher',1002),
--('VodafoneI Work from Home packs 2','Unlimited 50 GB',201,30,'4G Data Voucher',1002),
--('VodafoneI Work from Home packs 3','Unlimited 40 GB',151,30,'4G Data Voucher',1002),

--('VodafoneI Add on 1','Unlimited 800 MB ',11,28,'4G Data Voucher',1002),
--('VodafoneI Add on 2','Unlimited 2 GB ',21,28,'4G Data Voucher',1002),
--('VodafoneI Add on 3','Unlimited 6 GB ',51,28,'4G Data Voucher',1002);

-----International Roaming
--insert into Plans values
--('VodafoneI InFlight Connectivity','700 MB data, 100 mins Outgoing Voice Calls and 100 SMS',999,1,'International Roaming',1002),

--('VodafoneI Value WiFi Calling','Rs 1118.64  IR usage',1202,28,'International Roaming',1002),

--('VodafoneI Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',5751,30,'International Roaming',1002);

--select * from Plans where operator_id= 1002;



------------------BSNL---------------------------
---POPULAR PLANS

--insert into Plans values
--('BSNL 1 GB/DAY Packs','Rs.149 Truly Unlimited Calls',149,28,'Popular Plans',1003),

--('BSNL 1.5 GB/DAY Packs','Rs.379 Truly Unlimited Calls',379,28,'Popular Plans',1003),

--('BSNL 2 GB/DAY Packs','Rs.439 Truly Unlimited Calls',439,28,'Popular Plans',1003),

--('BSNL 3 GB/DAY Packs','Rs.538 Truly Unlimited Calls',538,28,'Popular Plans',1003);



----Top-Up

--insert into Plans values
--('BSNL 1000 Talktime','Rs 700  Talktime',1000,365,'Top-Up',1003),
--('BSNL 700 Talktime','Rs 700  Talktime',700,365,'Top-Up',1003),
--('BSNL 270 Talktime','Rs 70  Talktime',270,28,'Top-Up',1003),
--('BSNL 20 Talktime','Rs 14  Talktime',20,28,'Top-Up',1003),
--('BSNL 10 Talktime','Rs 7  Talktime',10,28,'Top-Up',1003);


-----4G Data Voucher

--insert into Plans values
--('BSNL StreamIt 1','250GB & BSNL StreamIt',1008,240,'4G Data Voucher',1003),
--('BSNL StreamIt 2','120GB & BSNL StreamIt',904,120,'4G Data Voucher',1003);

--insert into Plans values
--('BSNL Work from Home packs 1','Unlimited 70 GB',251,30,'4G Data Voucher',1003),
--('BSNL Work from Home packs 2','Unlimited 50 GB',201,30,'4G Data Voucher',1003),
--('BSNL Work from Home packs 3','Unlimited 40 GB',151,30,'4G Data Voucher',1003),

--('BSNL Add on 1','Unlimited 800 MB ',11,28,'4G Data Voucher',1003),
--('BSNL Add on 2','Unlimited 2 GB ',21,28,'4G Data Voucher',1003),
--('BSNL Add on 3','Unlimited 6 GB ',51,28,'4G Data Voucher',1003);

-----International Roaming
--insert into Plans values
--('BSNL InFlight Connectivity','700 MB data, 100 mins Outgoing Voice Calls and 100 SMS',999,1,'International Roaming',1003),

--('BSNL Value WiFi Calling','Rs 1118.64  IR usage',1202,28,'International Roaming',1003),

--('BSNL Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',5751,30,'International Roaming',1003);

--select * from Plans where operator_id = 1003;

select * from Users
select * from Admin
select * from Transactions
select * from Operator
select * from Plans








