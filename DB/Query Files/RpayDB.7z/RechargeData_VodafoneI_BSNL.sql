------------------VodafoneI---------------------------
---POPULAR PLANS

insert into Plans values
('1 GB/DAY Packs','Rs.119 Truly Unlimited Calls',119,28,'Popular Plans',1002),

('1.5 GB/DAY Packs','Rs.498 Truly Unlimited Calls',498,84,'Popular Plans',1002),
('1.5 GB/DAY Packs','Rs.389 Truly Unlimited Calls',389,56,'Popular Plans',1002),
('1.5 GB/DAY Packs','Rs.279 Truly Unlimited Calls',279,28,'Popular Plans',1002),

('2 GB/DAY Packs','Rs.1698 Truly Unlimited Calls',1698,365,'Popular Plans',1002),
('2 GB/DAY Packs','Rs.439 Truly Unlimited Calls',439,56,'Popular Plans',1002),
('2 GB/DAY Packs','Rs.339 Truly Unlimited Calls',339,28,'Popular Plans',1002),

('3 GB/DAY Packs','Rs.548 Truly Unlimited Calls',548,56,'Popular Plans',1002),
('3 GB/DAY Packs','Rs.438 Truly Unlimited Calls',438,28,'Popular Plans',1002);



--Top-Up

insert into Plans values
('700 Talktime','Rs 700  Talktime',700,365,'Top-Up',1002),
('400 Talktime','Rs 400  Talktime',400,365,'Top-Up',1002),
('70 Talktime','Rs 70  Talktime',70,28,'Top-Up',1002),
('20 Talktime','Rs 14  Talktime',20,28,'Top-Up',1002),
('10 Talktime','Rs 7  Talktime',10,28,'Top-Up',1002);


---4G Data Voucher

insert into Plans values
('VodafoneI Playback','250GB & Airtel Xstream',1008,240,'4G Data Voucher',1002),
('VodafoneI Playback','120GB & Airtel Xstream',904,120,'4G Data Voucher',1002);

insert into Plans values
('Work from Home packs','Unlimited 70 GB',251,30,'4G Data Voucher',1002),
('Work from Home packs','Unlimited 50 GB',201,30,'4G Data Voucher',1002),
('Work from Home packs','Unlimited 40 GB',151,30,'4G Data Voucher',1002),

('Add on','Unlimited 800 MB ',11,28,'4G Data Voucher',1002),
('Add on','Unlimited 2 GB ',21,28,'4G Data Voucher',1002),
('Add on','Unlimited 6 GB ',51,28,'4G Data Voucher',1002);

---International Roaming
insert into Plans values
('InFlight Connectivity','300 MB data, 100 mins Outgoing Voice Calls and 100 SMS',499,1,'International Roaming',1002),
('InFlight Connectivity','700 MB data, 100 mins Outgoing Voice Calls and 100 SMS',999,1,'International Roaming',1002),

('Value WiFi Calling','Rs 1000.20  IR usage',1102,28,'International Roaming',1002),
('Value WiFi Calling','Rs 1118.64  IR usage',1202,28,'International Roaming',1002),

('Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',575,1,'International Roaming',1002),
('Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',2875,7,'International Roaming',1002),
('Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',5751,30,'International Roaming',1002);

select * from Plans where operator_id= 1002;


------------------BSNL---------------------------
---POPULAR PLANS

insert into Plans values
('1 GB/DAY Packs','Rs.149 Truly Unlimited Calls',149,28,'Popular Plans',1003),

('1.5 GB/DAY Packs','Rs.698 Truly Unlimited Calls',698,84,'Popular Plans',1003),
('1.5 GB/DAY Packs','Rs.489 Truly Unlimited Calls',489,56,'Popular Plans',1003),
('1.5 GB/DAY Packs','Rs.379 Truly Unlimited Calls',379,28,'Popular Plans',1003),

('2 GB/DAY Packs','Rs.1998 Truly Unlimited Calls',1998,365,'Popular Plans',1003),
('2 GB/DAY Packs','Rs.639 Truly Unlimited Calls',639,56,'Popular Plans',1003),
('2 GB/DAY Packs','Rs.439 Truly Unlimited Calls',439,28,'Popular Plans',1003),

('3 GB/DAY Packs','Rs.748 Truly Unlimited Calls',748,56,'Popular Plans',1003),
('3 GB/DAY Packs','Rs.538 Truly Unlimited Calls',538,28,'Popular Plans',1003);



--Top-Up

insert into Plans values
('1000 Talktime','Rs 700  Talktime',1000,365,'Top-Up',1003),
('700 Talktime','Rs 700  Talktime',700,365,'Top-Up',1003),
('270 Talktime','Rs 70  Talktime',270,28,'Top-Up',1003),
('20 Talktime','Rs 14  Talktime',20,28,'Top-Up',1003),
('10 Talktime','Rs 7  Talktime',10,28,'Top-Up',1003);


---4G Data Voucher

insert into Plans values
('BSNL StreamIt','250GB & BSNL StreamIt',1008,240,'4G Data Voucher',1003),
('BSNL StreamIt','120GB & BSNL StreamIt',904,120,'4G Data Voucher',1003);

insert into Plans values
('Work from Home packs','Unlimited 70 GB',251,30,'4G Data Voucher',1003),
('Work from Home packs','Unlimited 50 GB',201,30,'4G Data Voucher',1003),
('Work from Home packs','Unlimited 40 GB',151,30,'4G Data Voucher',1003),

('Add on','Unlimited 800 MB ',11,28,'4G Data Voucher',1003),
('Add on','Unlimited 2 GB ',21,28,'4G Data Voucher',1003),
('Add on','Unlimited 6 GB ',51,28,'4G Data Voucher',1003);

---International Roaming
insert into Plans values
('InFlight Connectivity','300 MB data, 100 mins Outgoing Voice Calls and 100 SMS',499,1,'International Roaming',1003),
('InFlight Connectivity','700 MB data, 100 mins Outgoing Voice Calls and 100 SMS',999,1,'International Roaming',1003),

('Value WiFi Calling','Rs 1000.20  IR usage',1102,28,'International Roaming',1003),
('Value WiFi Calling','Rs 1118.64  IR usage',1202,28,'International Roaming',1003),

('Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',575,1,'International Roaming',1003),
('Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',2875,7,'International Roaming',1003),
('Unlimited WiFi Calling','Unlimited Incoming and Outgoing Voice Calls, Data & SMS',5751,30,'International Roaming',1003);

select * from Plans where operator_id = 1003;


select * from Plans